import gymnasium as gym
from stable_baselines3 import TD3
from stable_baselines3.common.callbacks import EvalCallback
from stable_baselines3.common.base_class import BaseAlgorithm
import argparse
import os

# class CustomEvalCallback(EvalCallback):
#     def __init__(self, env, n_eval_episodes=5, eval_freq=10000, best_model_save_path=None, log_path=None, model_save_path=None):
#         super().__init__(eval_env=env, n_eval_episodes=n_eval_episodes, eval_freq=eval_freq, best_model_save_path=best_model_save_path, log_path=log_path)
#         self.model_save_path = model_save_path

#     def _on_step(self) -> bool:
#         # if timestep is a multiple of 20000, save the model
#         if self.n_calls % 20000 == 0:
#             self.model.save(os.path.join(self.model_save_path, f"{self.n_calls}steps_model.zip"))

def main(env_name, timesteps):
    env = gym.make(env_name, max_episode_steps=150)#, tasks_to_complete=['microwave']) #continuing_task=False, max_episode_steps=150)
    model = TD3(
        "MultiInputPolicy",
        env,
        verbose=1,
        tensorboard_log=f"/ext_hdd/jjlee/jumpstart-rl/logs/{env_name}_guide_TD3",
    )
    
    model.learn(
        total_timesteps=timesteps,
        log_interval=10,
        progress_bar=True,
        # callback=CustomEvalCallback(
        #     env,
        #     n_eval_episodes=100,
        #     eval_freq=10000,
        #     model_save_path=f"examples/models/{env_name}_TD3"
        # )
        callback=EvalCallback(
            env,
            n_eval_episodes=100,
            best_model_save_path=f"/ext_hdd/jjlee/jumpstart-rl/examples/models/{env_name}_guide_TD3"
        ),
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=str, default="PointMaze_UMaze-v3")
    parser.add_argument("--timesteps", type=int, default=1e6)
    args = parser.parse_args()
    main(args.env, args.timesteps)
